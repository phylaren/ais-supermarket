import { Link, Outlet } from "react-router-dom"
import style from "./Main.module.css"

import { useContext } from "react"
import { UserContext } from "../context/UserContext"

import PageName from "../pageElems/PageName"
import headerStyle from "../pageElems/headerStyle.module.css"

import {cashier, manager} from "./categories.js";

function getCategories(role) {
    if (role === "CASHIER") return cashier;
    if (role === "MANAGER") return manager;
    return [];
}

export default function Main(){
    const role = useContext(UserContext);
    const categories = getCategories(role);

    return(
        <div className={style.pageContainer}>
            <PageName name="Головна"/>
            {<PageCategories categories={categories}/>}
        </div>
    )
}

//array of categories
export function PageCategories({categories}){
    return(
        <ul>
            {categories.map(category=>(
                <li key={category.eng}>
                    <Link to={`${category.eng}`}>{category.ukr}</Link>
                </li>
            ))}
        </ul>
    )
}